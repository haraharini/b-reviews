import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MenuItem } from 'primeng/api';
import { EmployeesService } from './employees.service';
import { IEmployee } from './IEmployee';
import { Component, OnInit } from '@angular/core';
import { SelectItem } from 'primeng/components/common/selectitem';
import { MessageService } from './message.service';
import {DomSanitizer, SafeResourceUrl, SafeUrl} from '@angular/platform-browser';
import { AuthenticationService } from './authentication.service';
import {ConfirmationService} from 'primeng/api';
import { User } from './Users';
import { Role } from './Role';
import { Router, ActivatedRoute } from '@angular/router';
import { saveAs } from 'file-saver';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
providers: [ MessageService ]
})
export class AppComponent implements OnInit {
  currentUser: User;
  [x: string]: SafeUrl;
  resJsonResponse: any;
  cols: any[];
  title = 'my-project';
  value: Date;
  employees: IEmployee[];
  employees1: IEmployee[] = [];
  employee: IEmployee ;

  employee1: IEmployee ;

selectedEmp: IEmployee;
displayDialog: boolean;
newEmployee: boolean;
    sortOptions: SelectItem[];

    sortKey: string;

    sortField: string;

    sortOrder: number;
    items: MenuItem[ ];
    display = false;

    uploadedFiles: any[] = [];
searchTerm: string;
  constructor(private empService: EmployeesService, private messageService: MessageService,
     private confirmationService: ConfirmationService, private authenticationService: AuthenticationService,
     private formBuilder: FormBuilder,
     private route: ActivatedRoute,

     private router: Router) {

      this.authenticationService.currentUser.subscribe(x => this.currentUser = x);
      if (this.authenticationService.currentUserValue) {
        this.router.navigate(['/home']);
    }

          }
          get f() { return this.loginForm.controls; }
          loginForm: FormGroup;
          loading = false;
          submitted = false;
          returnUrl: string;
          error = '';


   ngOnInit() {
    this.empService.getEmployees().subscribe((data) => this.employees = data);

    this.cols = [
      { field: 'name', header: 'name' },
      { field: 'date', header: 'date' },
      { field: 'reportType', header: 'reportType' },
      { field: 'market', header: 'market' },
      { field: 'period', header: 'period'}
  ];


    this.sortOptions = [
      {label: 'Report Name', value: 'name'},
      {label: 'market', value: 'market'}
  ];
  this.loginForm = this.formBuilder.group({
    username: ['', Validators.required],
    password: ['', Validators.required]
});

// reset login status
this.authenticationService.logout();

// get return url from route parameters or default to '/'
this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
  }


selectEmp(event: Event, employee: IEmployee) {
this.selectedEmp = employee;
this.displayDialog = true;
// event.preventDefault();
}
onSortChange(event) {
  const value = event.value;

  if (value.indexOf('!') === 0) {
      this.sortOrder = -1;
      this.sortField = value.substring(1, value.length);
  } else {
      this.sortOrder = 1;
      this.sortField = value;
  }
}
showDialogToAdd() {
//  this.newEmployee = true;
    // this.selectedEmp = employee;
  // tslint:disable-next-line:no-unused-expression
 //  this.employee ;  this.empService.getEmployees().subscribe((data) => this.employees = data);
  this.displayDialog = true;
}
save() {
// this.empService.updateEmployee(this.selectedEmp).subscribe(
 // () => this.employees );
 this.display11 = false;
 this.displayDialog = false;
}
showDialog(event: Event, employee: IEmployee) {
  this.newEmployee = true;
  this.selectedEmp = employee;
  this.display = true;
}
showDialogLogin(event: Event, employee: IEmployee) {
  this.displayLogin = true;

}
clickLogin() {
  this.displayLogin = false;
}
cancel() {
  this.display11 = false;
  this.displayDialog = false;
}
delete() {
  this.empService.deleteEmployee(this.selectedEmp.id).subscribe();
  this.displayDialog = false;
}
delete1() {
 // this.empService.deleteEmployee(this.employee.id).subscribe();
 this.empService.deleteEmployee(this.selectedEmp.id).subscribe();
 this.display = false;
}
showDialog1() {
 // this.newEmployee = true;
 // this.selectedEmp = employee;
  this.display11 = true;

}
logout() {
  this.authenticationService.logout();
  this.router.navigate(['/login']);
}
get isAdmin() {
    return this.currentUser && this.currentUser.role === Role.Admin;
}
/*
generateDownloadJsonUri() {
  const theJSON = JSON.stringify(this.resJsonResponse);
  const uri = this.sanitizer.bypassSecurityTrustUrl('destination/json;charset=UTF-8,' + encodeURIComponent(theJSON));
  this.downloadJsonHref = uri;
}  private sanitizer: DomSanitizer,*/
onDialogHide() {
  this.selectedEmp = null;
}


onRowSelect(event) {
  this.newEmployee = false;
  this.employee = this.cloneCar(event.data);
  this.displayDialog = true;
}

cloneCar(c: IEmployee): IEmployee {
  const employee = {};
  // tslint:disable-next-line:forin
  for (const prop in c) {
      employee[prop] = c[prop];
  }
  return ;
}


onUpload(event) {
  for (const file of event.files) {
      this.uploadedFiles.push(file);
  }

  this.messageService.add('File Uploaded');
}
onBasicUpload(event) {
  this.messageService.add('File Uploaded with Basic Mode');
}
openNav() {
  document.getElementById('mySidenav').style.width = '250px';
  document.getElementById('main').style.marginLeft = '250px';
}

closeNav() {
  document.getElementById('mySidenav').style.width = '0';
  document.getElementById('main').style.marginLeft = '0';
}


clear() {
this.selectedType = null;
this.selectedTypes = [];
this.selectedModes = [];
this.selectedEmp = null;
}

onSubmit() {
  this.submitted = true;

  // stop here if form is invalid
  if (this.loginForm.invalid) {
      return;
  }

  this.loading = true;
  this.authenticationService.login(this.f.username.value, this.f.password.value)
      .pipe(first())
      .subscribe(
          data => {
              this.router.navigate([this.returnUrl]);
          },
          error => {
              this.error = error;
              this.loading = false;
          });
}

}




// deleteRow (index: number) {
 // this.employee.splice(index, 1);
/*
downloadPDF(){
  const doc = new jsPDF();
  doc.text('sjdsdjshdsd', 10, 10);
  doc.save('test.pdf');
  } }*/

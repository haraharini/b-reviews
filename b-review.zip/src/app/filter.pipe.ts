
import { IEmployee } from './IEmployee';
import { PipeTransform, Pipe } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {
  transform(employees: IEmployee[], searchTerm: string): IEmployee[] {
    if (!employees || !searchTerm) {
      return employees;
    }

    return employees.filter(employee =>
       employee.name.toLowerCase().indexOf(searchTerm.toLowerCase()) !== -1);
   }
}
/*

export class EmployeeFilterPipe implements PipeTransform {
transform(employees: IEmployee[], searchTerm: string): IEmployee[] {
if (!employees || !searchTerm) {
  return employees;
}

return employees.filter(employee =>
   employee.name.toLowerCase().indexOf(searchTerm.toLowerCase()) !== -1);
}

}*/

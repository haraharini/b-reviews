import { Injectable } from '@angular/core';
import { IEmployee } from './IEmployee';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class MessageService {
  messages: string[] = [];
  private _url = '/assets/data/destination.json';
  constructor(private http: HttpClient) {

  }
  getEmployees(): Observable<IEmployee[]> {
  return this.http.get<IEmployee[]>(this._url);
  }


   add(message: string) {
     this.messages.push(message);
   }

   clear() {
     this.messages = [];
   }
  }

import { EmployeesService } from './../employees.service';
import { IEmployee } from './../IEmployee';
import { MessageService } from './../message.service';
import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {


  employees: IEmployee[];
  employees1: IEmployee[];
  employee: IEmployee ;
  employee1: IEmployee ;
  val: number;
  selectedEmp: IEmployee;

  items: Array<any> = [];
  item1: Array<any> = [];
  items1: Array<any> = [];
  books: Array<any> = [];
  images: any[];
  buttons: Array<any> = [];

  height: string;
  minHeight: string;
  arrowSize: string ;
  showArrows: boolean ;
/*


  disableSwiping: boolean = false;

  autoPlayInterval: number = 3333;
  stopAutoPlayOnSlide: boolean = true;
  debug: boolean = false;
  backgroundSize: string = 'cover';
  backgroundPosition: string = 'center center';
  backgroundRepeat: string = 'no-repeat';
  showDots: boolean = true;
  dotColor: string = '#FFF';
  showCaptions: boolean = true;
  captionColor: string = '#FFF';
  captionBackground: string = 'rgba(0, 0, 0, .35)';
  lazyLoad: boolean = false;
  hideOnNoSlides: boolean = false;
  width: string = '100%';
  fullscreen: boolean = false;

*/

  constructor(private empService: EmployeesService, private messageService: MessageService, private router: Router) {


    this.items = [
      { name: 'assets/showcase/images/1.jpg', id: 1 },
      { name: 'assets/showcase/images/2.jpg', id: 2 },
      { name: 'assets/showcase/images/3.jpg', id: 3 },
      { name: 'assets/showcase/images/4.jpg', id: 4 },
      { name: 'assets/showcase/images/5.jpg', id: 5 },
      { name: 'assets/showcase/images/6.jpg', id: 6 },
      { name: 'assets/showcase/images/7.jpg', id: 7},
      { name: 'assets/showcase/images/8.jpg', id: 8 },
      { name: 'assets/showcase/images/9.jpg', id: 9 },
      { name: 'assets/showcase/images/10.jpg', id: 10},
      { name: 'assets/showcase/images/11.jpg', id: 11 },
      { name: 'assets/showcase/images/12.jpg', id: 12 },

    ];
      this.item1 = [

        { name: 'assets/showcase/images/11.jpg' },
        { name: 'assets/showcase/images/12.jpg' },
        { name: 'assets/showcase/images/13.jpg' },
        { name: 'assets/showcase/images/14.jpg' },
        { name: 'assets/showcase/images/15.jpg' },
        { name: 'assets/showcase/images/16.jpg' },
        { name: 'assets/showcase/images/11.jpg' },
        { name: 'assets/showcase/images/12.jpg' },
        { name: 'assets/showcase/images/14.jpg' },
        { name: 'assets/showcase/images/15.jpg' },
        { name: 'assets/showcase/images/16.jpg' },
        { name: 'assets/showcase/images/11.jpg' },
        { name: 'assets/showcase/images/12.jpg' },
        { name: 'assets/showcase/images/14.jpg' },
      ];
this.buttons = [
{},
{},
{},
{}
];

   }

  ngOnInit() {
    this.empService.getEmployees().subscribe((data) => this.employees = data);
    this.empService.getEmployees().subscribe((data) => this.books = data);
    this.items1 = [
       'assets/showcase/images/d1.jpg' ,
        'assets/showcase/images/n4.jpg',
       'assets/showcase/images/n1.jpg' ,
      'assets/showcase/images/n2.jpg' ,
      'assets/showcase/images/n3.jpg',

];
}
onSelect(items) {
this.router.navigate(['/grid/grid1', items.id]);
}

// onSelect1(employees) {
 // this.router.navigate(['/grid/grid1', employees.id]);
 // }

}

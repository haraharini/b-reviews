import { Component, OnInit } from '@angular/core';

import { EmployeesService } from './../employees.service';
import { IEmployee } from './../IEmployee';


@Component({
  selector: 'app-grid11',
  templateUrl: './grid11.component.html',
  styleUrls: ['./grid11.component.css']
})
export class Grid11Component implements OnInit {
  employees: IEmployee[];
  employees1: IEmployee[];
  employee: IEmployee ;
  items: Array<any> = [];
  books: Array<any> = [];
  employee1: IEmployee ;
  val: number;
selectedEmp: IEmployee;

name = 'Angular 5';
images = [{
 // tslint:disable-next-line:max-line-length
 name: 'Image 1', url: 'https://4.bp.blogspot.com/-OuIrYzKE1lM/WJ1nqskJ5pI/AAAAAAAAOww/v9JfD7Hb_Fwe_K1svBN7gz2A_BUKxbqGwCLcB/s400/mindblowing-awasome-wallpapers-imgs.jpg'
},
{
 name: 'Image 2',
 url: 'https://akm-img-a-in.tosshub.com/indiatoday/559_102017023826.jpg?TZlWXro5W8Rj4VbO.MpENgo1F2MX93j'
}];
  constructor(private empService: EmployeesService) {
    this.items = [
      { name: 'assets/showcase/images/rb1.jpg', id: 1 },
      { name: 'assets/showcase/images/rb2.jpg', id: 2 },
      { name: 'assets/showcase/images/7.jpg', id: 3 },
      { name: 'assets/showcase/images/9.jpg', id: 4 },
      { name: 'assets/showcase/images/rb1.jpg', id: 1 },
      { name: 'assets/showcase/images/rb2.jpg', id: 2 },
      { name: 'assets/showcase/images/7.jpg', id: 3 },
      { name: 'assets/showcase/images/9.jpg', id: 4 },
      { name: 'assets/showcase/images/rb1.jpg', id: 1 },
      { name: 'assets/showcase/images/rb2.jpg', id: 2 },
      { name: 'assets/showcase/images/7.jpg', id: 3 },
      { name: 'assets/showcase/images/9.jpg', id: 4 },

    ];
  }

  ngOnInit() {
    this.empService.getEmployees().subscribe((data) => this.employees = data);
    this.empService.getEmployees().subscribe((data) => this.books = data);
  }


getBase64Image(img) {

  const canvas = document.createElement('canvas');
  console.log('image');
  canvas.width = img.width;
  canvas.height = img.height;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(img, 0, 0);
  const dataURL = canvas.toDataURL('image/png');
  return dataURL;
}

// var base64 = (document.getElementById("imageid"));
/*download() {
  const doc = new jsPDF();
  for (let i =0; i < this.images.length;i++) {
   const imageData = this.getBase64Image(document.getElementById('img' + i));
   console.log(imageData);
     doc.addImage(imageData, 'JPG', 10, (i + 1) * 10, 180, 150);
     doc.addPage();
  }
  doc.save('Test.pdf');
}
*/
  // tslint:disable-next-line:member-ordering

}

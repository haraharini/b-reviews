import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Grid11Component } from './grid11.component';

describe('Grid11Component', () => {
  let component: Grid11Component;
  let fixture: ComponentFixture<Grid11Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Grid11Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Grid11Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

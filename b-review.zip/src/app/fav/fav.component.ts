import { EmployeesService } from './../employees.service';
import { IEmployee } from './../IEmployee';
import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
@Component({
  selector: 'app-fav',
  templateUrl: './fav.component.html',
  styleUrls: ['./fav.component.css']
})
export class FavComponent implements OnInit {

  employees: IEmployee[];
  employees1: IEmployee[];
  employee: IEmployee ;
  items: Array<any> = [];
  books: Array<any> = [];
  employee1: IEmployee ;
  val: number;
selectedEmp: IEmployee;
  constructor(private empService: EmployeesService, private router: Router) {
  }

  ngOnInit() {
    this.empService.getEmployees1().subscribe((data) => this.employees = data);

  }
  onSelect(employees) {
    this.router.navigate(['/grid1', employees.id]);
    }
remove() {
  this.empService.deleteEmployee(this.selectedEmp.id).subscribe();

}
}

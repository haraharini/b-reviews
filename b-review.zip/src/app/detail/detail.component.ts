import { SafeUrl } from '@angular/platform-browser';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { EmployeesService } from './../employees.service';
import { IEmployee } from './../IEmployee';
import { Observable } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { UserService } from './../Users.service';
import { CommentsService } from './../comments.service';
import { AuthenticationService } from './../authentication.service';
import {ConfirmationService} from 'primeng/api';
import { User } from './../Users';
import { Role } from './../Role';
@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css']
})
export class DetailComponent implements OnInit {
  public Id;
  public Name;
  user: any;
  employees: IEmployee[];
  employees$: Observable<IEmployee[]>;
  selectedId: number;
  val1 = 3;
  text = '';
  currentUser: User;
  [x: string]: SafeUrl;

employees1: IEmployee[];
employee: IEmployee ;
employee1: IEmployee ;
selectedEmp: IEmployee;
displayDialog: boolean;
newEmployee: boolean;
display = false;
Users: User[];
users: IEmployee[];
selectedBook: IEmployee;
selectedItem: User;
  constructor(private route: ActivatedRoute, private empService: EmployeesService, private cService: CommentsService,
     private authenticationService: AuthenticationService) {
      this.authenticationService.currentUser.subscribe(x => this.currentUser = x);


      }

  ngOnInit() {
    this.empService.getEmployees().subscribe((data) => this.employees = data);
    const id = this.route.snapshot.params['id'];

    this.Id = id;
    // const id = +this.route.snapshot.paramMap.get('id');
    this.empService.getUser(id).subscribe(u => {

      this.user = u;
     });

    }
    selectEmp(event: Event, employee: IEmployee) {
      this.selectedEmp = employee;
      this.displayDialog = true;
      // event.preventDefault();
      }
      selectItem(event: Event, item: User) {
        this.selectedItem = item;
        this.displayDialog = true;
        // event.preventDefault();
        }
      selectBook(event: Event, book: IEmployee) {
        this.selectedBook = book;
        this.displayDialog = true;
        // event.preventDefault();
        }
      showDialogToAdd(event: Event, employee: IEmployee) {
        this.newEmployee = true;
        this.selectedEmp = employee;
        // tslint:disable-next-line:no-unused-expression
       //  this.employee ;  this.empService.getEmployees().subscribe((data) => this.employees = data);
        this.displayDialog = true;
      }

    // save() {
     //   this.cService.addComment(this.Users).subscribe(comments => this.Users.push(this.Users.id));
      //   this.displayDialog = false;
     // }
      fav() {
// this.employees.username = this.currentUser.username;
this.empService.addBook(this.user)
.subscribe(employee => this.employees.push(this.employee));

   //     this.userService.updateEmployee(this.selectedBook).subscribe(
     //     () => this.books );
     //    this.displayDialog = false;
        }
      showDialog(event: Event, employee: IEmployee) {
        this.newEmployee = true;
        this.selectedEmp = employee;
        this.display = true;
      }
      cancel() {
        this.empService.getEmployees().subscribe((data) => this.employees = data);
        this.displayDialog = false;
      }
     myFunction() {
      const dots = document.getElementById('dots');
      const moreText = document.getElementById('more');
      const btnText = document.getElementById('myBtn');

      if (dots.style.display === 'none') {
        dots.style.display = 'inline';
        btnText.innerHTML = 'Read more';
        moreText.style.display = 'none';
      } else {
        dots.style.display = 'none';
        btnText.innerHTML = 'Read less';
        moreText.style.display = 'inline';
      }
    }

    myFunction1() {
      location.reload();
      this.empService.getEmployees().subscribe((data) => this.employees = data);
    }


  }

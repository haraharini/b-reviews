import { FilterPipe } from './filter.pipe';
import { MessageService } from './message.service';
import { EmployeesService } from './employees.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS  } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {CalendarModule} from 'primeng/calendar';
import {DataViewModule} from 'primeng/dataview';
import {DropdownModule} from 'primeng/dropdown';
import {PanelModule} from 'primeng/panel';
import {DialogModule} from 'primeng/dialog';
import {DynamicDialogModule} from 'primeng/dynamicdialog';
import {TableModule} from 'primeng/table';
import { ListComponent } from './list/list.component';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { GridComponent } from './grid/grid.component';
import {MenuModule} from 'primeng/menu';
import {MenuItem} from 'primeng/api';
import {FileUploadModule} from 'primeng/fileupload';
import {OverlayPanelModule} from 'primeng/overlaypanel';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {ConfirmationService} from 'primeng/api';
import {ScrollPanelModule} from 'primeng/scrollpanel';
import {SelectButtonModule} from 'primeng/selectbutton';
import {DataTableModule} from 'primeng/datatable';
import {SplitButtonModule} from 'primeng/splitbutton';
import {PaginatorModule} from 'primeng/paginator';
import { HomeComponent } from './home/home.component';
import {CarouselModule} from 'primeng/carousel';
import {TabViewModule} from 'primeng/tabview';
import {ToastModule} from 'primeng/toast';
import {RatingModule} from 'primeng/rating';
import { SliderModule } from 'angular-image-slider';
import { Grid1Component } from './grid1/grid1.component';
import {InputTextareaModule} from 'primeng/inputtextarea';
import {CardModule} from 'primeng/card';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import {SlideshowModule} from 'ng-simple-slideshow';
import { DetailComponent } from './detail/detail.component';
import { LoginComponent } from './login/login.component';
import { AdminComponent } from './admin/admin.component';
import { AuthGuard } from './_guards';
import { JwtInterceptor, ErrorInterceptor } from './_helpers';
import { fakeBackendProvider } from './_helpers';
import { RegisterComponent } from './register/register.component';
import {TooltipModule} from 'primeng/tooltip';
import {  UserService } from './Users.service';
import { AuthenticationService } from './authentication.service';
import { Role } from './Role';
import { Grid2Component } from './grid2/grid2.component';
import { Grid3Component } from './grid3/grid3.component';
import { AboutComponent } from './about/about.component';
import { Grid11Component } from './grid11/grid11.component';
import { FavComponent } from './fav/fav.component';
// import {ChartModule} from 'primeng/chart';
import { ChartsComponent } from './charts/charts.component';
import { ChartsModule } from 'ng2-charts/ng2-charts';
@NgModule({
  declarations: [
    AppComponent,
    ListComponent,
    FilterPipe,
    GridComponent,
    HomeComponent,
    Grid1Component,
    PageNotFoundComponent,

    DetailComponent,

    LoginComponent,

    AdminComponent,

    RegisterComponent,

    Grid2Component,

    Grid3Component,

    AboutComponent,

    Grid11Component,

    FavComponent,

    ChartsComponent
  ],
  imports: [
    BrowserModule,
    RatingModule,
    TooltipModule,
    SlideshowModule,
    SliderModule,
    InputTextareaModule,
    TabViewModule,
    ToastModule,
    CarouselModule,
    SplitButtonModule,
    DataTableModule,
    PaginatorModule,
    ChartsModule,
    SelectButtonModule,
    FormsModule,
    CardModule,
    ScrollPanelModule,
    ReactiveFormsModule,
    OverlayPanelModule,
    ConfirmDialogModule,
    HttpClientModule,
    BrowserAnimationsModule,
    CalendarModule,
    DataViewModule,
    DropdownModule,
    PanelModule,
    DialogModule,
    DynamicDialogModule,
    TableModule,
    AppRoutingModule,
    MenuModule,
  FileUploadModule,
    RouterModule.forChild(
      [{path: '', redirectTo: '/home', pathMatch: 'full'},
       {path: 'list', component: ListComponent, canActivate: [AuthGuard]},
      {path: 'grid', component: GridComponent, canActivate: [AuthGuard]},
      {path: 'home', component: HomeComponent},
      {path: 'grid1/:id', component: DetailComponent, canActivate: [AuthGuard]},
      {path: 'grid1', component: Grid1Component, canActivate: [AuthGuard]},
      {path: 'grid11', component: Grid11Component, canActivate: [AuthGuard]},
      {path: 'login', component: LoginComponent},
      {path: 'admin', component: AdminComponent, canActivate: [AuthGuard]},
      {path: 'about', component: AboutComponent},
      {path: 'grid2', component: Grid2Component, canActivate: [AuthGuard]},
      {path: 'grid3', component: Grid3Component, canActivate: [AuthGuard]},
      {path: 'fav', component:  FavComponent, canActivate: [AuthGuard]},
      {path: 'charts', component:  ChartsComponent, canActivate: [AuthGuard]},
     // data: { roles: [Role.Admin]}},
      {path: 'register', component: RegisterComponent},
      {path: '**', component: PageNotFoundComponent}])
  ],
  providers: [EmployeesService, MessageService, ConfirmationService, UserService, AuthenticationService,
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
    fakeBackendProvider
],
  bootstrap: [AppComponent],
  exports: [RouterModule]
})
export class AppModule { }

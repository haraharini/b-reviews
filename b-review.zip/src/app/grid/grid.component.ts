import { MessageService } from './../message.service';
import { MenuItem } from 'primeng/api';
import { SelectItem } from 'primeng/components/common/selectitem';
import { SafeUrl } from '@angular/platform-browser';
import { Component, OnInit } from '@angular/core';
import { EmployeesService } from './../employees.service';
import { IEmployee } from './../IEmployee';
declare let jsPDF;
@Component({
  selector: 'app-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.css']
})
export class GridComponent implements OnInit {

  [x: string]: SafeUrl;
  resJsonResponse: any;
  cols: any[];
  title = 'my-project';
  value: Date;
  employees: IEmployee[];
  employees1: IEmployee[];
  employee: IEmployee ;

  employee1: IEmployee ;

selectedEmp: IEmployee;
displayDialog: boolean;
newEmployee: boolean;
    sortOptions: SelectItem[];
    sortOptions1: SelectItem[];
    sortKey: string;

    sortField: string;

    sortOrder: number;
    items: MenuItem[ ];
    display = false;

    uploadedFiles: any[] = [];
  constructor(private empService: EmployeesService) {

   }

  ngOnInit() {
    this.empService.getEmployees().subscribe((data) => this.employees = data);


      this.sortOptions = [
        { label: 'Sort By', value: ' ' },
        {label: 'Title', value: 'name'},
        {label: 'Publication year', value: 'date'},
        {label: 'Author', value: 'author'},
        {label: 'Genre', value: 'genre'}
    ];
    this.sortOptions1 = [
      { label: 'Genre', value: ' ' },
      {label: 'Thriller', value: 'thriller'},
      {label: 'Slice of life', value: 'slice of life'},
      {label: 'Inspiration', value: 'inspiration'},
      {label: 'Mystery', value: 'mystery'},
      {label: 'Love', value: 'love'},
      {label: 'Comedy', value: 'comedy'},
      {label: 'Horror', value: 'horror'},
      {label: 'Fantasy', value: 'fantasy'}
  ];
  }
  selectEmp(event: Event, employee: IEmployee) {
    this.selectedEmp = employee;
    this.displayDialog = true;
    // event.preventDefault();
    }
    onSortChange(event) {
      const value = event.value;

      if (value.indexOf('!') === 0) {
          this.sortOrder = -1;
          this.sortField = value.substring(1, value.length);
      } else {
          this.sortOrder = 1;
          this.sortField = value;
      }
    }
    onSortChange1(event) {
      const value = event.value;

      if (value.indexOf('!') === 0) {
          this.sortOrder = -1;
          this.sortField = value.substring(1, value.length);
      } else {
          this.sortOrder = 1;
          this.sortField = value;
      }
    }
    showDialogToAdd(event: Event, employee: IEmployee) {
      this.newEmployee = true;
      this.selectedEmp = employee;
      // tslint:disable-next-line:no-unused-expression
     //  this.employee ;  this.empService.getEmployees().subscribe((data) => this.employees = data);
      this.displayDialog = true;
    }

    save() {
    this.empService.updateEmployee(this.selectedEmp).subscribe(
      () => this.employees );
     this.displayDialog = false;
    }
    showDialog(event: Event, employee: IEmployee) {
      this.newEmployee = true;
      this.selectedEmp = employee;
      this.display = true;
    }
    cancel() {
      this.empService.getEmployees().subscribe((data) => this.employees = data);
      this.displayDialog = false;
    }
    delete() {
      this.empService.deleteEmployee(this.selectedEmp.id).subscribe();
      this.displayDialog = false;
    }
    delete1() {
     // this.empService.deleteEmployee(this.employee.id).subscribe();
     this.empService.deleteEmployee(this.selectedEmp.id).subscribe();
     this.display = false;
    }
    onDialogHide() {
      this.selectedEmp = null;
    }


    onRowSelect(event) {
      this.newEmployee = false;
      this.employee = this.cloneCar(event.data);
      this.displayDialog = true;
    }

    cloneCar(c: IEmployee): IEmployee {
      const employee = {};
      // tslint:disable-next-line:forin
      for (const prop in c) {
          employee[prop] = c[prop];
      }
      return ;
    }

download(e) {
  const doc = new jsPDF('l');
  const col = ['id', 'book-name', 'author', 'genre'];
  const rows = [];


const arr = [];
arr.push(this.employees[e - 1].id);
arr.push(this.employees[e - 1].name);
arr.push(this.employees[e - 1].author);
arr.push(this.employees[e - 1].genre);


  rows.push(arr);

console.log(rows);
  doc.autoTable(col, rows, {

    styles: { overflow: 'linebreak', columnWidth: 'auto' },
    columnStyles: {
      1: {
      columnWidth: 'auto'


      }
    }

  });

  doc.save('books.pdf');
}



    clear() {
    this.selectedType = null;
    this.selectedTypes = [];
    this.selectedModes = [];
    this.selectedEmp = null;
    }


}

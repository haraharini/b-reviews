
import { User } from './Users';
import { Role } from './Role';
export interface IEmployee {
  id: number;
  name: string;
  market: string;
  date: string;
  genre: string;
  author: string;
rating: number;
review1: string;
review2: string;
summary: string;
username: string;
comments: any;
 }

import { Component, OnInit } from '@angular/core';

import { EmployeesService } from './../employees.service';
import { IEmployee } from './../IEmployee';
@Component({
  selector: 'app-grid1',
  templateUrl: './grid1.component.html',
  styleUrls: ['./grid1.component.css']
})
export class Grid1Component implements OnInit {
  employees: IEmployee[];
  employees1: IEmployee[];
  employee: IEmployee ;
  items: Array<any> = [];
  books: Array<any> = [];
  employee1: IEmployee ;
  val: number;
selectedEmp: IEmployee;
  constructor(private empService: EmployeesService) {
    this.items = [
      { name: 'assets/showcase/images/rb1.jpg', id: 1 },
      { name: 'assets/showcase/images/rb2.jpg', id: 2 },
      { name: 'assets/showcase/images/7.jpg', id: 3 },
      { name: 'assets/showcase/images/9.jpg', id: 4 },
      { name: 'assets/showcase/images/rb1.jpg', id: 1 },
      { name: 'assets/showcase/images/rb2.jpg', id: 2 },
      { name: 'assets/showcase/images/7.jpg', id: 3 },
      { name: 'assets/showcase/images/9.jpg', id: 4 },
      { name: 'assets/showcase/images/rb1.jpg', id: 1 },
      { name: 'assets/showcase/images/rb2.jpg', id: 2 },
      { name: 'assets/showcase/images/7.jpg', id: 3 },
      { name: 'assets/showcase/images/9.jpg', id: 4 },

    ];
  }

  ngOnInit() {
    this.empService.getEmployees().subscribe((data) => this.employees = data);
    this.empService.getEmployees().subscribe((data) => this.books = data);
  }

}

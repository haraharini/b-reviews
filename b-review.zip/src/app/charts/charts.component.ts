import { Component, OnInit } from '@angular/core';
import { Chart} from 'node_modules/chart.js';
import { EmployeesService } from './../employees.service';
import { IEmployee } from './../IEmployee';
@Component({
  selector: 'app-charts',
  templateUrl: './charts.component.html',
  styleUrls: ['./charts.component.css']
})
export class ChartsComponent implements OnInit {
  rating: Object;
  data: any;
  chart: any;
  employees: IEmployee[];
// rating: number;
  constructor(private empService: EmployeesService) {

       }

  public barChartOptions: any = {
    scaleShowVerticalLines: false,
    responsive: true
  };
  public barChartLabels: string[] = ['1985', '1986', '1987', '1988', '1989', '1990', '1991'];
  public barChartType = 'bar';
  public barChartLegend = true;

  public barChartData: any[] = [
    {data: [2, 3, 0, 0, 1, 1, 5], label: 'Thriller'},
    {data: [5, 4, 1, 0, 0, 1, 2], label: 'Comedy'},
    {data: [2, 3, 5, 0, 1, 1, 5], label: 'Inspiration'},
    {data: [5, 4, 1, 0, 3, 1, 2], label: 'Horror'}

  ];

  // events
  public chartClicked(e: any): void {
    console.log(e);
  }

  public chartHovered(e: any):  void {
    console.log(e);
  }

  ngOnInit() {
    this.empService.getChartData().then((data) => {

       this.employees = data;
       console.log(this.employees);
      });
  console.log(this.employees);
  }


  public randomize(): void {
    // Only Change 3 values
    const data = [
      Math.round(Math.random() * 100),
      59,
      80,
      (Math.random() * 100),
      56,
      (Math.random() * 100),
      40];
    const clone = JSON.parse(JSON.stringify(this.barChartData));
    clone[0].data = data;
    this.barChartData = clone;
    /**
     * (My guess), for Angular to recognize the change in the dataset
     * it has to change the dataset variable directly,
     * so one way around it, is to clone the data, change it and then
     * assign it;
     this.data = {
      labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
      datasets: [
          {
              label: 'My First dataset',
              backgroundColor: '#42A5F5',
              borderColor: '#1E88E5',
              data: [65, 59, 80, 81, 56, 55, 40]
          },
          {
              label: 'My Second dataset',
              backgroundColor: '#9CCC65',
              borderColor: '#7CB342',
              data: [28, 48, 40, 19, 86, 27, 90]
          }
      ]
  };
*/
  }


}




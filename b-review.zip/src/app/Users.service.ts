import { Injectable } from '@angular/core';
import { HttpClient,  HttpHeaders} from '@angular/common/http';
import { Observable, throwError, pipe } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { map } from 'rxjs/operators';
import { User } from './Users';
import { IEmployee } from './IEmployee';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'Authorization': 'my-auth-token'
  })
};
@Injectable({ providedIn: 'root' })
export class UserService {
  private _url = 'http://localhost:3100/users';
  private url = 'http://localhost:3100/users';
    constructor(private http: HttpClient) { }

    getAll(): Observable<User[]> {
      return this.http.get<User[]>(this._url);
    }

    getById(id: number) {
        return this.http.get('http://localhost:3100/users/' + id);
    }

    register(user: User) {
        return this.http.post('http://localhost:3100/users/register', user);
    }

    update(user: User): Observable<void> {
      return this.http.put<void>(`${this._url}/${user.id}`, user, {
        headers: new HttpHeaders ({
        'Content-Type': 'application/json'
        })
          });

    }

    delete(id: number): Observable<void> {
        return this.http.delete<void>(`${this._url}/${id}`);
    }
    getEmployees(): Observable<User[]> {
      // return this.http.get<IEmployee[]>(this._url);
      return this.http.get<User[]>(this._url);
      }
     updateEmployee(employees: User): Observable<void> {
       return this.http.post<void>(`${this._url}/${employees.id}`, employees, {
     headers: new HttpHeaders ({
     'Content-Type': 'application/json'
     })
       });
      //    .pipe(catchError(this.handleError));
     }
     deleteEmployee(id: number): Observable<void> {
       return this.http.delete<void>(`${this._url}/${id}`);
     }
}



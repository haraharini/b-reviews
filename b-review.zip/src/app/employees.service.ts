import { Injectable } from '@angular/core';
import { IEmployee } from './IEmployee';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError, pipe } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { map } from 'rxjs/operators';
import { User } from './Users';
import { AuthenticationService } from './authentication.service';
import { Role } from './Role';
const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'Authorization': 'my-auth-token'
  })
};
@Injectable()
export class EmployeesService {
  [x: string]: any;
  currentUser: User;
 // y: string;
// y = this.currentUser;
// private _url = '/assets/data/employees.json';
 private _url = 'http://localhost:3000/employees';
 private url = 'http://localhost:3000/books-';
 constructor(private http: HttpClient,  private authenticationService: AuthenticationService) {
  this.authenticationService.currentUser.subscribe(x => this.currentUser = x);
 }
 getEmployees(): Observable<IEmployee[]> {
 // return this.http.get<IEmployee[]>(this._url);
 return this.http.get<IEmployee[]>(this._url);
 }
updateEmployee(employees: IEmployee): Observable<void> {
  return this.http.put<void>(`${this._url}/${employees.id}`, employees, {
headers: new HttpHeaders ({
'Content-Type': 'application/json'
})
  });
 //    .pipe(catchError(this.handleError));
}
deleteEmployee(id: number): Observable<void> {
  return this.http.delete<void>(`${this._url}/${id}`);
}

getUser(id: number) {
return this.http.get('http://localhost:3000/employees/' + id);
}
addBook (employees: IEmployee): Observable<IEmployee[]> {
 // if (this.currentUser.role === Role.Admin) {
  return this.http.post<IEmployee[]>(`${this.url}${this.currentUser.username}`, employees, httpOptions);

 // } else {
 // return this.http.post<IEmployee[]>('http://localhost:3000/books-user1', employees, httpOptions);
//   }
}
getEmployees1(): Observable<IEmployee[]> {
  // return this.http.get<IEmployee[]>(this._url);
 // if (this.currentUser.role === Role.Admin) {
  return this.http.get<IEmployee[]>(`${this.url}${this.currentUser.username}`);
 // } else {
 //   return this.http.get<IEmployee[]>('http://localhost:3000/books-user1');
 // }
  }
addComment (employees: IEmployee): Observable<IEmployee[]> {

  return this.http.post<IEmployee[]>('http://localhost:3200/comments', employees, httpOptions);


}
getRate(rating: number) {
  return this.http.get('http://localhost:3000/employees/' + rating);
  }
  getChartData(): Promise<IEmployee[]> {
    // return this.http.get<IEmployee[]>(this._url);
    return this.http.get<IEmployee[]>(this._url).toPromise();
    }
}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grid3',
  templateUrl: './grid3.component.html',
  styleUrls: ['./grid3.component.css']
})
export class Grid3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { AuthenticationService } from './authentication.service';
import { Injectable } from '@angular/core';

import { HttpClient,  HttpHeaders} from '@angular/common/http';
import { Observable, throwError, pipe } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { map } from 'rxjs/operators';
import { User } from './Users';
import { IEmployee } from './IEmployee';
const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'Authorization': 'my-auth-token'
  })
};
@Injectable({
  providedIn: 'root'
})
export class CommentsService {
  private url = 'http://localhost:3200/comments';
  constructor(private http: HttpClient,  private authenticationService: AuthenticationService) { }
  addComment (username: string): Observable<User[]> {

      return this.http.post<User[]>('http://localhost:3200/comments', username, httpOptions);


    }

deleteEmployee(id: number): Observable<void> {
  return this.http.delete<void>(`${this.url}/${id}`);
}
}
